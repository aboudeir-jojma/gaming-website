"use strict";
!(function () {
  var e = {
      "en-US": {
        title: "Software update needed",
        message:
          "This content is not supported because your device's software appears to be out-of-date.",
        "android-tip":
          "On Android, fix this by making sure the [a1]Android System Webview[/a1] app has updates enabled and is up-to-date.",
        "ios-tip":
          "Alternatively if [b]Lockdown mode[/b] is enabled, try turning it off to view this content.",
        "general-tip":
          "Try installing any available software updates. Alternatively try on a different device.",
      },
      "es-ES": {
        title: "Actualización de software necesaria",
        message:
          "Este contenido no es compatible porque el software de tu dispositivo parece no estar actualizado.",
        "android-tip":
          "En Android, para solucionarlo, asegúrate de que la aplicación [a1]Android System Webview[/a1] tiene las actualizaciones activadas y está al día.",
        "ios-tip":
          "Alternativamente, si el [b]Modo de bloqueo[/b] está activado, intenta desactivarlo para ver este contenido.",
        "general-tip":
          "Intenta instalar las actualizaciones de software disponibles. También puedes probar con otro dispositivo.",
      },
      "hr-HR": {
        title: "Potrebno ažuriranje softvera",
        message:
          "Ovaj sadržaj nije podržan jer softver vašeg uređaja zastario.",
        "android-tip":
          "Na Androidu, popravite to na način da provjerite ima li [a1]Android System Webview[/a1] aplikacija uključena ažuriranja i je ažurna.",
        "ios-tip":
          "Alternativno ako je uključen [b]Lockdown mod[/b], pokušajte ga ugasiti kako bi vidjeli ovaj sadržaj.",
        "general-tip":
          "Pokušajte instalirati dostupna softverska ažuriranja. Alternativno, probajte na drugom uređaju.",
      },
      "pt-BR": {
        title: "Atualização de software necessária",
        message:
          "Esse conteúdo não é suportado porque o software do seu dispositivo parece estar desatualizado.",
        "android-tip":
          "No Android, é possível consertar esse erro certificando-se de que o aplicativo [a1]Android System Webview[/a1] tem atualizações habilitadas e está na versão mais recente.",
        "ios-tip":
          "De outro modo, se o [b]Modo Lockdown[/b] está ativo, tente desligá-lo para poder ver o conteúdo.",
        "general-tip":
          "Tente instalar qualquer atualização de software disponível. De outro modo, tente em um dispositivo diferente.",
      },
      "zh-CN": {
        title: "软件需要更新",
        message: "由于您设备上的软件版本过低，暂时无法运行此内容。",
        "android-tip":
          "在安卓系统上，要解决这个问题，请确保 [a1]Android System Webview[/a1] 应用程序已启用自动更新并处于最新状态。",
        "ios-tip":
          "如果您的设备处于[b]锁定模式[/b]，请在系统设置 - 隐私与安全性，关闭锁定模式再次尝试。",
        "general-tip": "请尝试更新系统版本，或者更换另一台设备运行。",
      },
      "zh-TW": {
        title: "軟體需要更新",
        message: "由於您的裝置軟體似乎已過時，因此不支援此內容。",
        "android-tip":
          "在 Android 上，要解決此問題，請確保 [a1]Android System Webview[/a1] 已啟用更新並且是最新版本。",
        "ios-tip":
          "另外，如果您的裝置已啟用 [b]封鎖模式[/b]，請嘗試關閉以檢視此內容。",
        "general-tip": "嘗試更新軟體，或者嘗試在不同的裝置上執行。",
      },
    },
    a = navigator.languages || [navigator.language],
    t = function (a) {
      var t = a.toLowerCase();
      for (var i in e) {
        var o = i.toLowerCase();
        if (t.startsWith(o)) return e[i];
        var n = t.split("-"),
          r = o.split("-");
        if (n[0] === r[0] && "zh" !== n[0]) return e[i];
      }
      return null;
    },
    i = null;
  for (var o of a) if ((i = t(o))) break;
  i || (i = e["en-US"]);
  var n = function (e, a) {
      var t = i[e];
      return (
        (t = (t = t.replace("[b]", "<strong>")).replace("[/b]", "</strong>")),
        a &&
          (t = (t = t.replace("[a1]", '<a href="' + a + '">')).replace(
            "[/a1]",
            "</a>"
          )),
        t
      );
    },
    r = [];
  if (
    (!!document.createElement("canvas").getContext("webgl") || r.push("WebGL"),
    "undefined" == typeof WebAssembly && r.push("WebAssembly"),
    (window["Intl"] && window["Intl"]["Segmenter"]) ||
      r.push("Internationalization support (Intl.Segmenter)"),
    window["C3_ModernJSSupport_OK"] || r.push("Modern JavaScript support"),
    0 === r.length)
  )
    window["C3_IsSupported"] = !0;
  else {
    var s = document.createElement("div");
    (s.id = "notSupportedWrap"), document.body.appendChild(s);
    var d = document.createElement("h2");
    (d.id = "notSupportedTitle"),
      (d.textContent = n("title")),
      s.appendChild(d);
    var p = document.createElement("p");
    p.className = "notSupportedMessage";
    var l = n("message"),
      u = navigator.userAgent;
    /android/i.test(u)
      ? (l +=
          "<br><br>" +
          n(
            "android-tip",
            "https://play.google.com/store/apps/details?id=com.google.android.webview"
          ))
      : /iphone|ipad|ipod/i.test(u)
      ? (l += " " + n("ios-tip"))
      : (l += " " + n("general-tip")),
      (l +=
        "<br><br><em>Missing features: " +
        r.join(", ") +
        "<br>User agent: " +
        navigator.userAgent +
        "</em>"),
      (p.innerHTML = l),
      s.appendChild(p),
      document.addEventListener("deviceready", () => {
        navigator["splashscreen"] &&
          navigator["splashscreen"]["hide"] &&
          navigator["splashscreen"]["hide"]();
      });
  }
})();
